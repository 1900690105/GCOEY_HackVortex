"use client";
import React from "react";
import JobAssessment from "../[p]/components/JobAssisment";
import TakeAssisment from "./components/StartAssisment";

function page() {
  return (
    <div>
      <TakeAssisment />
    </div>
  );
}

export default page;

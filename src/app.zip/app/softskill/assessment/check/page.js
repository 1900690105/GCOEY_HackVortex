"use client";
import React from "react";
import SoftSkillInterviewUI from "../components/UI";

function page() {
  return (
    <div>
      {/* <SoftSkillsAssessment /> */}
      <SoftSkillInterviewUI />
    </div>
  );
}

export default page;

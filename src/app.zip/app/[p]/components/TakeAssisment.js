import React from "react";
import JobAssessment from "./JobAssisment";

function TakeAssisment() {
  return (
    <div>
      <JobAssessment />
    </div>
  );
}

export default TakeAssisment;

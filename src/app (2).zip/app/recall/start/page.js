import React from "react";
import NotesSection from "../components/NotesSection";
import CourseInterface from "../components/NotesSection";

const page = () => {
  return (
    <div>
      <CourseInterface />
    </div>
  );
};

export default page;

import React from "react";

function ExpandContent() {
  return <div></div>;
}

export default ExpandContent;

export default function CourseLayout({ children }) {
  return <div>{children}</div>;
}
